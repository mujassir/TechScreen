DROP TABLE ScreenerSkillxRef
GO

DROP TABLE Question
GO


DROP TABLE Skill
GO


DROP TABLE Position      
GO     

DROP TABLE Screening
GO

DROP TABLE Recruiter
GO

DROP TABLE Candidate
GO

DROP TABLE Screener
GO

DROP TABLE Client
GO

DROP TABLE TopLevelClient
GO

DROP TABLE ScreeningQA
GO

DROP TABLE AnswerStatus
GO

DROP TABLE ScreeningStatus
GO